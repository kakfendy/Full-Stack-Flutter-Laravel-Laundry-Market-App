class AppAssets {
  static const String bgAuth = "assets/bg_auth.jpg";
  static const String placeholderlaundry = "assets/placeholder_laundry.jpg";
  static const String profile = "assets/profile.jpg";
  static const String emptyBG = "assets/empty_background.jpg";
  static const String wa = "assets/wa.png";
}
